from brainspace._version import __version__


# Default rendering
OFF_SCREEN = False
